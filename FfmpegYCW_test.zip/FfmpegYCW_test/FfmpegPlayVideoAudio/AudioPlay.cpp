#include "stdafx.h"
#include "AudioPlay.h"


AudioPlay::AudioPlay()
{
}


AudioPlay::~AudioPlay()
{
}
