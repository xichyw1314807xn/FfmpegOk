#pragma once
class VideoPlay
{
public:
	VideoPlay();
	~VideoPlay();
};

