#pragma once
class AudioPlay
{
public:
	AudioPlay();
	~AudioPlay();
};

