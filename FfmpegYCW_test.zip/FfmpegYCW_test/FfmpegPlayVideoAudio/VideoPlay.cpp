#include "stdafx.h"
#include "VideoPlay.h"


VideoPlay::VideoPlay()
{
}


VideoPlay::~VideoPlay()
{
}
