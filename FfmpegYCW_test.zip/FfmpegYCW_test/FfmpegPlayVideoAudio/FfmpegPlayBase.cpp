#include "stdafx.h"
#include "FfmpegPlayBase.h"


FfmpegPlayBase::FfmpegPlayBase()
{
}


FfmpegPlayBase::~FfmpegPlayBase()
{
}


void FfmpegPlayBase::playHttpFile()
{
}

void FfmpegPlayBase::playLocalFile()
{

}
