#include "stdafx.h"
#include "FfmpegDecodecBase.h"


FfmpegDecodecBase::FfmpegDecodecBase()
{
}


FfmpegDecodecBase::~FfmpegDecodecBase()
{
}

void FfmpegDecodecBase::decodec()
{
}

void FfmpegDecodecBase::encodec()
{
}