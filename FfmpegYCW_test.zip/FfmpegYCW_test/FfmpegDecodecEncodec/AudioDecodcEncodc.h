#pragma once
#include "FfmpegDecodecBase.h"
class AudioDecodcEncodc : public FfmpegDecodecBase
{
public:
	AudioDecodcEncodc();
	~AudioDecodcEncodc();
	 void decodec();
	 void encodec();
};

