// FfmpegDecodecEncodec.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "FfmpegDecodecBase.h"
#include "AudioDecodcEncodc.h"
#include "VideoDecodcEncodc.h"
#include "PictureDecodcEncodec.h"


#define AUDIO_DECODC 1
#define VIDEO_DECODC 0
#define PICTURE_DECODC 0

int _tmain(int argc, _TCHAR* argv[])
{
#if AUDIO_DECODC
	FfmpegDecodecBase *pAudioFfmpegBase = new AudioDecodcEncodc();
	pAudioFfmpegBase->decodec();
	pAudioFfmpegBase->encodec();
#endif

#if VIDEO_DECODC
	FfmpegDecodecBase *pVideoFfmpegBase = new VideoDecodcEncodc();
	pVideoFfmpegBase->decodec();
	pVideoFfmpegBase->encodec();
#endif
#if PICTURE_DECODC
	FfmpegDecodecBase *pPictureFfmpegBase = new PictureDecodcEncodec();
	pPictureFfmpegBase->decodec();
	pPictureFfmpegBase->encodec();
#endif

	return 0;
}

