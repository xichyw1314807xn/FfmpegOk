#include "stdafx.h"
#include "PictureDecodcEncodec.h"


PictureDecodcEncodec::PictureDecodcEncodec()
{
}


PictureDecodcEncodec::~PictureDecodcEncodec()
{
}

void PictureDecodcEncodec::decodec()
{
	
		printf("********* Hello picture decodec **********\n ");
}

void PictureDecodcEncodec::encodec()
{

		printf("********* Hello picture encodec **********\n ");
}